/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pooairbnb.design.interfaces;

import pooairbnb.design.clases.Reservacion;

/**
 *
 * @author julio.nava
 */
public interface IRentar {

      public abstract void reservar(Reservacion reservacion);
    
}
