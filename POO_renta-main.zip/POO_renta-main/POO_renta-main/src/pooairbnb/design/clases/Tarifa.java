/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pooairbnb.design.clases;

/**
 *
 * @author julio.nava
 */
public class Tarifa {
    
    private double precioPorNoche;
    private int intervaloInicio;
    private int intervaloFin;

    /**
     * @return the precioPorNoche
     */
    public double getPrecioPorNoche() {
        return precioPorNoche;
    }

    /**
     * @param precioPorNoche the precioPorNoche to set
     */
    public void setPrecioPorNoche(double precioPorNoche) {
        this.precioPorNoche = precioPorNoche;
    }

    /**
     * @return the intervaloInicio
     */
    public int getIntervaloInicio() {
        return intervaloInicio;
    }

    /**
     * @param intervaloInicio the intervaloInicio to set
     */
    public void setIntervaloInicio(int intervaloInicio) {
        this.intervaloInicio = intervaloInicio;
    }

    /**
     * @return the intervaloFin
     */
    public int getIntervaloFin() {
        return intervaloFin;
    }

    /**
     * @param intervaloFin the intervaloFin to set
     */
    public void setIntervaloFin(int intervaloFin) {
        this.intervaloFin = intervaloFin;
    }
    
    
    
}
